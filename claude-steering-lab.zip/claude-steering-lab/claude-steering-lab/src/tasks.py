# タスクのデータ操作ロジック。
# このファイルには Path-scoped Rule は掛かっていない（src/api.py だけが対象）。
# 実験②で「ここを触ってもルールは発動しない」ことを確認するのに使う。

# メモリ上のタスク置き場
_tasks = []
_next_id = 1


def add_task(title):
    """タスクを1件追加して返す"""
    global _next_id
    task = {"id": _next_id, "title": title, "done": False}
    _next_id += 1
    _tasks.append(task)
    return task


def list_tasks():
    """全タスクを返す"""
    return list(_tasks)


def complete_task(task_id):
    """指定IDのタスクを完了にする。見つからなければ None"""
    for task in _tasks:
        if task["id"] == task_id:
            task["done"] = True
            return task
    return None


# このファイルを直接実行したときの簡易テスト
if __name__ == "__main__":
    add_task("ブログ記事を読む")
    add_task("ラボで実験する")
    complete_task(1)
    print("tasks:", list_tasks())
    print("OK: tasks.py の簡易テスト完了")
