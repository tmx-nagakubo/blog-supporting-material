# タスク API のエンドポイント定義（HTTPフレームワークは使わず、関数で擬似的に表現）。
#
# 【仕組み②: Path-scoped Rule の対象ファイル】
# .claude/rules/api-validation.md が paths: ["src/api.py"] で
# このファイルだけにスコープされている。
# 実験②で「ここに新しいエンドポイントを足して」と頼むと、
# Claude は入力検証コードを必ず入れてくるはず。

from tasks import add_task, list_tasks, complete_task


def create_task(payload):
    """POST /tasks 相当: タスクを作成する"""
    # 入力検証（このプロジェクトの API 規約）
    title = (payload or {}).get("title")
    if not isinstance(title, str) or title.strip() == "":
        return {"status": 400, "error": "title は空でない文字列が必須です"}
    task = add_task(title.strip())
    return {"status": 201, "body": task}


def get_tasks():
    """GET /tasks 相当: タスク一覧を返す"""
    return {"status": 200, "body": list_tasks()}


def mark_complete(task_id):
    """POST /tasks/:id/complete 相当: タスクを完了にする"""
    # 入力検証
    if not isinstance(task_id, int) or isinstance(task_id, bool) or task_id <= 0:
        return {"status": 400, "error": "id は正の整数が必須です"}
    task = complete_task(task_id)
    if task is None:
        return {"status": 404, "error": "タスクが見つかりません"}
    return {"status": 200, "body": task}


# スモークテスト
if __name__ == "__main__":
    print(create_task({"title": "API経由で追加"}))
    print(create_task({"title": ""}))  # 400 になるはず
    print(get_tasks())
    print(mark_complete(1))
    print(mark_complete(-1))  # 400 になるはず
    print("OK: api.py のスモークテスト完了")
