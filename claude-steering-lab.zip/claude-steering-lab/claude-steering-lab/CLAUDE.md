# claude-steering-lab
## プロジェクト概要
依存ゼロの小さなタスク管理 API。Claude Code の操縦の仕組みを学ぶための教材です。

## コマンド
- 動作確認 / テスト実行: `python src/tasks.py`
- API のスモークテスト: `python src/api.py`
- （Lint やビルドはこの教材には用意していません）

## ディレクトリ構成
- `src/tasks.py` — タスクのデータ操作ロジック
- `src/api.py`   — タスク API のエンドポイント定義
- `.claude/`     — 操縦の仕組み一式（rules / skills / agents / hooks）

## チーム規約（事実として常に守るもの）
- コードと識別子は英語、コメントは日本語で書く。
- 関数は小さく保ち、1関数1責務にする。
