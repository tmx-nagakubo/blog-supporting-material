import sys
import os
import json
from datetime import datetime, timezone

# Windows でも UTF-8 で stdin を確実に読むため、バイト列で受けてからデコードする
# （テキストモードの sys.stdin.read() は環境によっては空を返すため）
raw = sys.stdin.buffer.read().decode("utf-8", errors="replace")
file_path = "(unknown)"
tool = "(unknown)"
try:
    data = json.loads(raw or "{}")
    tool = data.get("tool_name", tool)
    file_path = (data.get("tool_input") or {}).get("file_path", file_path)
    # カレント(プロジェクトルート)からの相対パスにする。
    # 外側のファイルなら相対化せずファイル名だけにする。
    base = data.get("cwd") or os.getcwd()
    if file_path not in ("(unknown)", "") and os.path.isabs(file_path):
        rel = os.path.relpath(file_path, base)
        file_path = os.path.basename(file_path) if rel.startswith("..") else rel
    file_path = file_path.replace("\\", "/")
except Exception:
    pass

# タイムスタンプは ISO 文字列で記録
ts = datetime.now(timezone.utc).isoformat()
line = f"{ts}\t{tool}\t{file_path}\n"

log_dir = os.path.join(os.getcwd(), "logs")
try:
    os.makedirs(log_dir, exist_ok=True)
    with open(os.path.join(log_dir, "edits.log"), "a", encoding="utf-8") as f:
        f.write(line)
except Exception:
    # ログ失敗は致命的ではないので握りつぶす
    pass

sys.exit(0)
