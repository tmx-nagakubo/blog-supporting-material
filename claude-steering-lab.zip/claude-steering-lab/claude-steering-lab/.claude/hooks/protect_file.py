import sys
import json

# Windows でも UTF-8 で stdin を確実に読むため、バイト列で受けてからデコードする
# （テキストモードの sys.stdin.read() は環境によっては空を返すため）
raw = sys.stdin.buffer.read().decode("utf-8", errors="replace")
file_path = ""
try:
    data = json.loads(raw or "{}")
    # PreToolUse の入力は tool_input にツール引数が入る
    file_path = (data.get("tool_input") or {}).get("file_path", "")
except Exception:
    # パースできなければ素通り（教材なので寛容に）
    pass

normalized = file_path.replace("\\", "/")
if normalized.lower().endswith("protected.md"):
    # stderr に理由を書いて exit 2 → ツール実行をブロック
    sys.stderr.write(
        "⛔ PROTECTED.md は保護されています。Hook(PreToolUse) により編集をブロックしました。"
    )
    sys.exit(2)

# それ以外は許可
sys.exit(0)
