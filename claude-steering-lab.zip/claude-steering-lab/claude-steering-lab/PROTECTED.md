# PROTECTED（編集ブロックのデモ用）

このファイルは `.claude/hooks/protect-file.js` の `PreToolUse` フックによって
編集が **拒否** されます。

実験⑤で「PROTECTED.md を編集して」と頼むと、フックが exit code 2 を返し、
Claude のファイル編集がブロックされることを確認できます。

ポイント: CLAUDE.md に「このファイルは触らないで」と書いても確実ではありません。
本当に守らせたいなら、こうした Hook（または権限設定）で仕組みとして強制します。
